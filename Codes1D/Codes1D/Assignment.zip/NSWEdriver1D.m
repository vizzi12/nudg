close all
% Driver script for solving the 1D advection equations
Globals1D;

g=9.81;

% % Order of polymomials used for approximation 

N = 16;
% % Generate simple mesh
[Nv, VX, K, EToV] = MeshGen1D(0,50,10);

% Initialize solver and construct grid and metric


StartUp1D;
% bx=zeros(size(x(1,:)));
% bx(x(2,:) > 10 & x(2,:) < 30)=-00.1;
% bx=ones(N+1,1).*bx;
bx=zeros(size(x));

h=3.5*ones(size(x(1,:)));
h(x(2,:) > 20)=1.25;
h=ones(N+1,1).*h;
u=zeros(size(x));
q=h.*u;

% plot(x(:),h(:))
% hold on
FinalTime = 2.5;
[h,q] = NSWE1D(h,q,FinalTime,bx);

x2=x;

%%
plot(x(:),h(:),'linewidth',2)


load dambreakdata
hold on
plot(x,h,'linewidth',2)
legend('DG-FEM','\texttt{dambreakdata}','location','northeast','Interpreter', 'Latex', 'FontSize', 15)
xlabel('$x$', 'Interpreter', 'Latex', 'FontSize', 15)
ylabel('$ h$', 'Interpreter', 'Latex','FontSize', 15)


%%
figure
plot(x2(:),q(:),'linewidth',2)
hold on
plot(x,hu,'linewidth',2)
legend('DG-FEM','\texttt{dambreakdata}','location','best','Interpreter', 'Latex', 'FontSize', 15)
xlabel('$x$', 'Interpreter', 'Latex', 'FontSize', 15)
ylabel('$ hu$', 'Interpreter', 'Latex','FontSize', 15)

