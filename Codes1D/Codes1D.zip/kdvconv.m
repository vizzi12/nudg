clear all
close all
clc

error=zeros(3,3);

i=1;
for N=[1,2,3]
    j=1;
    for kk=2.^(4:8)
        % Generate simple mesh
       [Nv, VX, K, EToV] = MeshGen1D(-20,30,kk);
        
        % Initialize solver and construct grid and metric
        StartUp1D;
        
        % Set initial conditions
        c=1;
        x0=-5;
        u = c/2*sech(0.5*sqrt(c)*(x-c(1)*0-x0)).^2;
        
        % Solve Problem
        FinalTime = 2;
        [u,time] = kdv1D(u,FinalTime,c,x0);
        ua=c/2*sech(0.5*sqrt(c)*(x-c(1)*FinalTime-x0)).^2;
        
        err = ua - u; % compute point-wise error
        M = inv(V*V'); % mass matrix
        errL2 = zeros(K,1);
        for k = 1 : K
            errL2(k) = err(:,k)'*diag(J(:,k))*M*err(:,k);
        end
        error(i,j) = sqrt(sum(errL2)); % Global L^2-norm of error
        j=j+1;
        
    end
    i=i+1
end

%%
figure
for i=1:3
    loglog(2.^(4:8),error(i,:),'-*','linewidth',2)
    hold on
end
loglog(2.^(4:8),5*(2.^(4:8)).^(-1.5),'--','linewidth',2)
loglog(2.^(4:8),100*(2.^(4:8)).^(-3),'--','linewidth',2)
loglog(2.^(4:8),15*(2.^(4:8)).^(-3),'--','linewidth',2)
legend('$N=1$','$N=2$','$N=3$','$\mathcal{O}(h^{1.5})$','$\mathcal{O}(h^3)$','$\mathcal{O}(h^{3})$','location','southwest','Interpreter', 'Latex', 'FontSize', 15)
xlabel('$K$', 'Interpreter', 'Latex', 'FontSize', 15)
ylabel('$\| \varepsilon_h(T)\|$', 'Interpreter', 'Latex','FontSize', 15)
