function [rhsu] = AdvecRHS1D(u,time, a)

% function [rhsu] = AdvecRHS1D(u,time)
% Purpose  : Evaluate RHS flux in 1D advection

Globals1D;

% form field differences at faces
% alpha=0;
du = zeros(Nfp*Nfaces,K); 

alpha=0;

% du(:) = (u(vmapM)-u(vmapP)).*((2*a(vmapM).*a(vmapP))./(a(vmapP)+a(vmapM)).*nx(:)-(1-alpha)*abs((2*a(vmapM).*a(vmapP))./(a(vmapP)+a(vmapM)).*nx(:)))/2;
% du(:)=nx(:).*(a(vmapM).*u(vmapM)-0.5*(a(vmapM).*u(vmapM)+a(vmapP).*u(vmapP)));
% du(:)=0.5*nx(:).*(a(vmapM).*u(vmapM)+a(vmapP).*u(vmapP));

% du(:)= 0.5*nx(:).*(a(vmapM).*u(vmapM)+a(vmapP).*u(vmapP));

du(:)= nx(:).*(a(vmapM).*u(vmapM)-(0.5*(a(vmapM).*u(vmapM)+a(vmapP).*u(vmapP))+0.75*nx(:).*(u(vmapM)-u(vmapP))));
% du(:)=0.5*nx(:).*(a(vmapM).*u(vmapM)+a(vmapP).*u(vmapP));

% du(:)=nx(:).*(2*a(vmapM).*a(vmapP))./(a(vmapP)+a(vmapM)).*( 0.5*(u(vmapM)+u(vmapP)) + 0.5*(nx(:).*u(vmapM)-nx(:).*u(vmapP))    );
% du(:)=nx(:).*(a(vmapM).*u(vmapM)- du(:));

% impose boundary condition at x=0
uin = sin(pi*(-2 - time));
% uout = sin(pi*(x(vmapO)-a(vmapO)*time));
% du (mapI) = (u(vmapI)- uin ).*(a(vmapI)*nx(mapI)-(1-alpha)*abs(a(vmapI)*nx(mapI)))/2;
% du(mapI)=0.5*nx(mapI).*(a(vmapI).*u(vmapI)+a(vmapI).*uin);
du(mapI) = nx(mapI).*(2*a(vmapI).*a(vmapI))./(a(vmapI)+a(vmapI)).*( 0.5*(u(vmapI)+uin) + 0.5*(nx(mapI).*u(mapI)-nx(mapI).*uin)    );
% du(mapI)=nx(mapI).*(a(vmapI).*u(vmapI)- du(mapI));

du(mapI)= nx(mapI).*(a(mapI)*u(mapI)-(0.5*(a(mapI).*u(vmapI)+a(mapI).*uin)+0.75*nx(mapI)*(u(vmapI)-uin)));
du(mapO)=0;
% du(mapO)=a(vmapO)*u(vmapO);

% du(mapI)=0.5*nx(mapI).*(a(vmapI)*u(vmapI)+ a(vmapI)*uin);
% du (mapI) = nx(mapI)*(a(vmapI)*u(vmapI)-0.5*(a(vmapI)*u(vmapI)+a(vmapI)*uin));
% du (mapO) = 2*a(vmapO).*a(vmapO)./(a(vmapO)+a(vmapO)).*nx(mapO).*( 0.5*(a(vmapO).*u(vmapO)+a(vmapO).*uout) + 0.5*(nx(mapO).*u(mapO)-nx(mapO).*uout)    );

% du (mapI) = nx(mapI)*(a(vmapI)*u(vmapI)-0.5*(a(vmapI)*u(vmapI)+a(vmapI)*uin));
% du (mapI) = (u(vmapI)- uin ).*(a(vmapI)*nx(mapI)-(1-alpha)*abs(a(vmapI)*nx(mapI)))/2;

% uout = sin(pi*(x(vmapO)-a(vmapO)*time));
% du (mapO) = nx(mapO)*(a(vmapO)*u(vmapO)-0.5*(a(vmapO)*u(vmapO)+a(vmapO)*uout));
% du (mapO) = 0;

Dra=zeros(size(a));
Dra(N+1,45)=0.5;
Dra(1,46)=0.5;

Dra(1,76)=-0.5;
Dra(N+1,75)=-0.5;

Dra(1,1)=1;
Dra(end)=-1;

rhsg=-rx.*cos(pi*(-x + a*time)).*(Dra).*a*time*pi;
% rhsg=rx.*(-pi*a.*cos(pi*(x - a*time)) + pi*a.*(1 - Dra*time).*cos(pi*(x - a*time)));
% compute right hand sides of the semi-discrete PDE
rhsu = a.*(-rx.*(Dr*u))+(LIFT*(Fscale.*du));%+rhsg;
% 
% rhsu = a.*rx.*((V*V')*((V*V')\Dr)'*u) - LIFT*(Fscale.*(du))+rhsg;
% temp=rx.*a.*(((V*V')\Dr)'*u);
% rhsu = ((V*V')*temp)- LIFT*(Fscale.*(du));
% rhsu = a.*rx.*(*((V*V')\Dr)'*u) - LIFT*(Fscale.*(du));
return
