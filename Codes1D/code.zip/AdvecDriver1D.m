% Driver script for solving the 1D advection equations
close all
clear all
clc

Globals1D;

% Order of polymomials used for approximation 
N = 4;
k=120;

% Generate simple mesh
[Nv, VX, K, EToV] = MeshGen1D(-2,2,k);

% Initialize solver and construct grid and metric
StartUp1D;

% Set initial conditions
a=ones(size(x));
a(abs(x) <= 0.5) = 1.5;
a(N+1,45)=1;
a(1,76)=1;

u = sin(pi*(x - a*0));
plot(x,u); 
FinalTime = 1;
[u] = Advec1D(u,FinalTime,a);
plot(x,u); 

ua=  sin(pi*(x - a*FinalTime));
hold on
plot(x(:),ua(:)); 

err = ua - u; % compute point-wise error
M = inv(V*V'); % mass matrix
errL2 = zeros(K,1);
for k = 1 : K
    errL2(k) = err(:,k)'*diag(J(:,k))*M*err(:,k);
end
errL2 = sqrt(sum(errL2)) % Global L^2-norm of errors



